(function($) {
"use strict";
	$('.grid').isotope({
		itemSelector: '.grid-item'
	});
	AOS.init();
})(jQuery);